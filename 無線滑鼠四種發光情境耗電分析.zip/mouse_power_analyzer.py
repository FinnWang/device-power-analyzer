#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
無線滑鼠耗電分析工具模組
可重複使用的分析和視覺化工具

使用方法：
1. 單檔分析：
   python mouse_power_analyzer.py single path/to/file.csv

2. 多檔比較：
   python mouse_power_analyzer.py multi path/to/file1.csv path/to/file2.csv ...

3. 作為模組使用：
   from mouse_power_analyzer import MousePowerAnalyzer
   analyzer = MousePowerAnalyzer()
   analyzer.analyze_files(['file1.csv', 'file2.csv'])
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import argparse
import sys
import warnings
warnings.filterwarnings('ignore')

class MousePowerAnalyzer:
    """無線滑鼠耗電分析器"""
    
    def __init__(self):
        """初始化分析器"""
        self.setup_matplotlib()
        self.colors = {
            'Nolight': '#2E8B57',      # 海綠色
            'Breath': '#4169E1',       # 皇家藍
            'Colorcycle': '#FF6347',   # 番茄紅
            'Flash': '#FFD700',        # 金色
            'Unknown': '#808080'       # 灰色
        }
        
        self.mode_names = {
            'Nolight': '無燈光',
            'Breath': '呼吸燈',
            'Colorcycle': '彩色循環',
            'Flash': '閃爍',
            'Unknown': '未知模式'
        }
    
    def setup_matplotlib(self):
        """設定matplotlib中文字體"""
        import matplotlib.font_manager as fm
        
        # 尋找可用的中文字體
        chinese_fonts = []
        for font in fm.fontManager.ttflist:
            if 'Noto' in font.name and ('CJK' in font.name or 'Sans' in font.name):
                chinese_fonts.append(font.name)
        
        if chinese_fonts:
            plt.rcParams['font.family'] = chinese_fonts[:1] + ['DejaVu Sans']
        else:
            plt.rcParams['font.family'] = ['SimHei', 'DejaVu Sans']
        
        plt.rcParams['axes.unicode_minus'] = False
        plt.rcParams['figure.dpi'] = 300
        plt.rcParams['savefig.dpi'] = 300
        plt.rcParams['font.size'] = 10
    
    def load_csv_file(self, filepath, mode_name=None):
        """
        載入CSV檔案
        
        Args:
            filepath: CSV檔案路徑
            mode_name: 模式名稱（可選，會自動從檔名推測）
            
        Returns:
            pandas.DataFrame: 處理後的資料
        """
        try:
            df = pd.read_csv(filepath)
            
            # 檢查欄位數量和名稱
            if len(df.columns) >= 4:
                df.columns = ['Time', 'Voltage', 'Current', 'Power']
            else:
                raise ValueError(f"CSV檔案欄位數量不足，需要至少4欄，實際有{len(df.columns)}欄")
            
            # 如果沒有指定模式名稱，從檔名推測
            if mode_name is None:
                filename = Path(filepath).stem.lower()
                for mode in self.mode_names.keys():
                    if mode.lower() in filename:
                        mode_name = mode
                        break
                else:
                    mode_name = 'Unknown'
            
            df['Mode'] = mode_name
            df['Mode_CN'] = self.mode_names.get(mode_name, mode_name)
            
            # 資料清理
            df = df.dropna()
            df = df[df['Power'] >= 0]
            df = df.sort_values('Time').reset_index(drop=True)
            
            return df
            
        except Exception as e:
            print(f"載入檔案 {filepath} 時發生錯誤：{e}")
            return None
    
    def calculate_statistics(self, df):
        """
        計算統計數據
        
        Args:
            df: 資料DataFrame
            
        Returns:
            dict: 統計結果
        """
        duration = df['Time'].max() - df['Time'].min()
        total_energy = np.trapz(df['Power'], df['Time'])
        
        stats = {
            'mode': df['Mode'].iloc[0],
            'mode_cn': df['Mode_CN'].iloc[0],
            'duration_s': duration,
            'data_points': len(df),
            'avg_voltage_V': df['Voltage'].mean(),
            'avg_current_A': df['Current'].mean(),
            'avg_current_mA': df['Current'].mean() * 1000,
            'avg_power_W': df['Power'].mean(),
            'avg_power_mW': df['Power'].mean() * 1000,
            'max_power_W': df['Power'].max(),
            'max_power_mW': df['Power'].max() * 1000,
            'min_power_W': df['Power'].min(),
            'min_power_mW': df['Power'].min() * 1000,
            'std_power_W': df['Power'].std(),
            'std_power_mW': df['Power'].std() * 1000,
            'total_energy_J': total_energy,
            'cv_power': df['Power'].std() / df['Power'].mean() if df['Power'].mean() > 0 else 0
        }
        
        return stats
    
    def estimate_battery_life(self, avg_power_W, battery_capacity_mAh=1000, voltage=3.7):
        """
        估算電池續航時間
        
        Args:
            avg_power_W: 平均功率 (瓦特)
            battery_capacity_mAh: 電池容量 (毫安時)
            voltage: 電池電壓 (伏特)
            
        Returns:
            dict: 續航時間估算
        """
        battery_energy_J = battery_capacity_mAh * voltage * 3.6  # 轉換為焦耳
        
        if avg_power_W > 0:
            hours = battery_energy_J / (avg_power_W * 3600)
            days = hours / 24
            
            return {
                'hours': hours,
                'days': days,
                'battery_capacity_mAh': battery_capacity_mAh,
                'voltage': voltage
            }
        else:
            return {'hours': float('inf'), 'days': float('inf')}
    
    def create_single_analysis(self, df, output_dir='./'):
        """建立單檔分析圖表"""
        
        mode = df['Mode'].iloc[0]
        mode_cn = df['Mode_CN'].iloc[0]
        color = self.colors.get(mode, '#1f77b4')
        
        Path(output_dir).mkdir(exist_ok=True)
        
        fig = plt.figure(figsize=(16, 12))
        fig.suptitle(f'{mode_cn} 模式 - 詳細耗電分析', fontsize=18, fontweight='bold')
        
        gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)
        
        # 1. 功率時間序列
        ax1 = fig.add_subplot(gs[0, :2])
        ax1.plot(df['Time'], df['Power']*1000, color=color, linewidth=1.5, alpha=0.8)
        mean_power = df['Power'].mean() * 1000
        ax1.axhline(y=mean_power, color='red', linestyle='--', alpha=0.7, 
                   label=f'平均值: {mean_power:.2f} mW')
        ax1.set_title('功率變化時間序列', fontweight='bold')
        ax1.set_xlabel('時間 (秒)')
        ax1.set_ylabel('功率 (mW)')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 2. 統計摘要
        ax2 = fig.add_subplot(gs[0, 2])
        stats = self.calculate_statistics(df)
        battery_life = self.estimate_battery_life(stats['avg_power_W'])
        
        stats_text = f"""統計摘要：
        
平均功率：{stats['avg_power_mW']:.2f} mW
最大功率：{stats['max_power_mW']:.2f} mW
最小功率：{stats['min_power_mW']:.2f} mW
標準差：{stats['std_power_mW']:.2f} mW

平均電流：{stats['avg_current_mA']:.2f} mA
平均電壓：{stats['avg_voltage_V']:.3f} V

測量時間：{stats['duration_s']:.1f} 秒
資料點數：{stats['data_points']} 筆

總消耗能量：{stats['total_energy_J']:.3f} J

預估續航 (1000mAh)：
{battery_life['hours']:.1f} 小時
{battery_life['days']:.1f} 天"""
        
        ax2.text(0.05, 0.95, stats_text, transform=ax2.transAxes, 
                 fontsize=9, verticalalignment='top', 
                 bbox=dict(boxstyle='round', facecolor='lightgray', alpha=0.8))
        ax2.set_xlim(0, 1)
        ax2.set_ylim(0, 1)
        ax2.axis('off')
        
        # 3. 電流時間序列
        ax3 = fig.add_subplot(gs[1, 0])
        ax3.plot(df['Time'], df['Current']*1000, color=color, linewidth=1.5, alpha=0.8)
        ax3.set_title('電流變化', fontweight='bold')
        ax3.set_xlabel('時間 (秒)')
        ax3.set_ylabel('電流 (mA)')
        ax3.grid(True, alpha=0.3)
        
        # 4. 功率分布直方圖
        ax4 = fig.add_subplot(gs[1, 1])
        ax4.hist(df['Power']*1000, bins=40, color=color, alpha=0.7, edgecolor='black')
        ax4.set_title('功率分布', fontweight='bold')
        ax4.set_xlabel('功率 (mW)')
        ax4.set_ylabel('頻次')
        ax4.grid(True, alpha=0.3)
        
        # 5. 累積能量消耗
        ax5 = fig.add_subplot(gs[1, 2])
        time_intervals = np.diff(np.concatenate([[0], df['Time']]))
        cumulative_energy = np.cumsum(df['Power'] * time_intervals)
        ax5.plot(df['Time'], cumulative_energy, color=color, linewidth=2)
        ax5.set_title('累積能量消耗', fontweight='bold')
        ax5.set_xlabel('時間 (秒)')
        ax5.set_ylabel('累積能量 (J)')
        ax5.grid(True, alpha=0.3)
        
        # 6. 功率變化率
        ax6 = fig.add_subplot(gs[2, 0])
        if len(df) > 1:
            power_diff = np.diff(df['Power'])
            time_diff = np.diff(df['Time'])
            power_rate = power_diff / time_diff
            ax6.plot(df['Time'][1:], power_rate*1000, color=color, alpha=0.7)
        ax6.set_title('功率變化率', fontweight='bold')
        ax6.set_xlabel('時間 (秒)')
        ax6.set_ylabel('功率變化率 (mW/s)')
        ax6.grid(True, alpha=0.3)
        
        # 7. 電壓穩定性
        ax7 = fig.add_subplot(gs[2, 1])
        ax7.plot(df['Time'], df['Voltage'], color=color, linewidth=1.5, alpha=0.8)
        ax7.set_title('電壓穩定性', fontweight='bold')
        ax7.set_xlabel('時間 (秒)')
        ax7.set_ylabel('電壓 (V)')
        ax7.grid(True, alpha=0.3)
        
        # 8. 功率 vs 電流散點圖
        ax8 = fig.add_subplot(gs[2, 2])
        ax8.scatter(df['Current']*1000, df['Power']*1000, color=color, alpha=0.6, s=10)
        ax8.set_title('功率 vs 電流關係', fontweight='bold')
        ax8.set_xlabel('電流 (mA)')
        ax8.set_ylabel('功率 (mW)')
        ax8.grid(True, alpha=0.3)
        
        plt.tight_layout()
        filename = f'{output_dir}/{mode}_detailed_analysis.png'
        plt.savefig(filename, bbox_inches='tight', dpi=300)
        plt.close()
        
        return filename
    
    def create_comparison_analysis(self, data_dict, output_dir='./'):
        """建立多檔比較分析"""
        
        Path(output_dir).mkdir(exist_ok=True)
        
        # 1. 綜合比較圖
        fig = plt.figure(figsize=(20, 16))
        fig.suptitle('無線滑鼠不同發光模式耗電分析報告', fontsize=20, fontweight='bold', y=0.98)
        
        gs = fig.add_gridspec(4, 4, hspace=0.3, wspace=0.3)
        
        modes = list(data_dict.keys())
        mode_names_cn = [data_dict[mode]['Mode_CN'].iloc[0] for mode in modes]
        colors = [self.colors.get(mode, '#1f77b4') for mode in modes]
        
        # 平均功率比較
        ax1 = fig.add_subplot(gs[0, 0])
        avg_powers = [data_dict[mode]['Power'].mean()*1000 for mode in modes]
        bars = ax1.bar(mode_names_cn, avg_powers, color=colors, alpha=0.8, edgecolor='black')
        ax1.set_title('平均功率比較', fontweight='bold')
        ax1.set_ylabel('平均功率 (mW)')
        ax1.grid(True, alpha=0.3, axis='y')
        
        for bar, power in zip(bars, avg_powers):
            ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
                    f'{power:.1f}', ha='center', va='bottom', fontweight='bold')
        
        # 電池續航估算
        ax2 = fig.add_subplot(gs[0, 1])
        battery_hours = []
        for mode in modes:
            avg_power_W = data_dict[mode]['Power'].mean()
            battery_life = self.estimate_battery_life(avg_power_W)
            battery_hours.append(battery_life['hours'])
        
        bars = ax2.bar(mode_names_cn, battery_hours, color=colors, alpha=0.8, edgecolor='black')
        ax2.set_title('預估電池續航 (1000mAh)', fontweight='bold')
        ax2.set_ylabel('續航時間 (小時)')
        ax2.grid(True, alpha=0.3, axis='y')
        
        for bar, hours in zip(bars, battery_hours):
            ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
                    f'{hours:.0f}h', ha='center', va='bottom', fontweight='bold')
        
        # 功率分布箱型圖
        ax3 = fig.add_subplot(gs[0, 2:])
        power_data = [data_dict[mode]['Power']*1000 for mode in modes]
        bp = ax3.boxplot(power_data, labels=mode_names_cn, patch_artist=True)
        for patch, color in zip(bp['boxes'], colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        ax3.set_title('功率分布比較', fontweight='bold')
        ax3.set_ylabel('功率 (mW)')
        ax3.grid(True, alpha=0.3, axis='y')
        
        # 時間序列比較
        ax4 = fig.add_subplot(gs[1, :])
        for mode in modes:
            df = data_dict[mode]
            time_norm = (df['Time'] - df['Time'].min()) / (df['Time'].max() - df['Time'].min()) * 100
            ax4.plot(time_norm, df['Power']*1000, 
                    color=self.colors.get(mode, '#1f77b4'), 
                    label=df['Mode_CN'].iloc[0], alpha=0.8, linewidth=2)
        
        ax4.set_title('功率時間序列比較', fontweight='bold', fontsize=14)
        ax4.set_xlabel('時間進度 (%)')
        ax4.set_ylabel('功率 (mW)')
        ax4.legend(loc='upper right')
        ax4.grid(True, alpha=0.3)
        
        # 個別模式時間序列
        for i, mode in enumerate(modes):
            df = data_dict[mode]
            mode_cn = df['Mode_CN'].iloc[0]
            color = self.colors.get(mode, '#1f77b4')
            
            ax = fig.add_subplot(gs[2, i])
            ax.plot(df['Time'], df['Power']*1000, color=color, linewidth=1, alpha=0.8)
            ax.set_title(f'{mode_cn}\n功率變化', fontweight='bold')
            ax.set_xlabel('時間 (秒)')
            ax.set_ylabel('功率 (mW)')
            ax.grid(True, alpha=0.3)
            
            ax = fig.add_subplot(gs[3, i])
            ax.hist(df['Power']*1000, bins=30, color=color, alpha=0.7, edgecolor='black')
            ax.set_title(f'{mode_cn}\n功率分布', fontweight='bold')
            ax.set_xlabel('功率 (mW)')
            ax.set_ylabel('頻次')
            ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        comparison_file = f'{output_dir}/comprehensive_comparison.png'
        plt.savefig(comparison_file, bbox_inches='tight', dpi=300)
        plt.close()
        
        # 2. 統計表格
        stats_file = self.create_statistics_table(data_dict, output_dir)
        
        return [comparison_file, stats_file]
    
    def create_statistics_table(self, data_dict, output_dir):
        """建立統計表格"""
        
        fig, ax = plt.subplots(figsize=(16, 10))
        fig.suptitle('詳細統計摘要表', fontsize=18, fontweight='bold')
        
        modes = list(data_dict.keys())
        colors = [self.colors.get(mode, '#1f77b4') for mode in modes]
        
        # 建立統計表格
        stats_data = []
        baseline_power = None
        if 'Nolight' in data_dict:
            baseline_power = data_dict['Nolight']['Power'].mean()
        
        for mode in modes:
            df = data_dict[mode]
            stats = self.calculate_statistics(df)
            battery_life = self.estimate_battery_life(stats['avg_power_W'])
            
            # 計算相對增加百分比
            if baseline_power and mode != 'Nolight':
                power_increase = ((stats['avg_power_W'] - baseline_power) / baseline_power * 100)
                increase_text = f"+{power_increase:.0f}%"
            else:
                increase_text = "基準" if mode == 'Nolight' else "N/A"
            
            stats_data.append([
                stats['mode_cn'],
                f"{stats['avg_power_mW']:.2f}",
                f"{stats['max_power_mW']:.2f}",
                f"{stats['min_power_mW']:.2f}",
                f"{stats['std_power_mW']:.2f}",
                f"{stats['avg_current_mA']:.2f}",
                f"{stats['duration_s']:.1f}",
                f"{stats['total_energy_J']:.3f}",
                increase_text,
                f"{battery_life['hours']:.0f}"
            ])
        
        columns = ['模式', '平均功率\n(mW)', '最大功率\n(mW)', '最小功率\n(mW)', '功率標準差\n(mW)', 
                   '平均電流\n(mA)', '測量時間\n(秒)', '總能量\n(J)', '相對增加', '預估續航\n(小時)']
        
        table = ax.table(cellText=stats_data, colLabels=columns, 
                        cellLoc='center', loc='center',
                        colColours=['lightsteelblue']*len(columns))
        
        table.auto_set_font_size(False)
        table.set_fontsize(12)
        table.scale(1.2, 2.5)
        
        # 設定表格樣式
        for i in range(len(modes)):
            for j in range(len(columns)):
                cell = table[(i+1, j)]
                if j == 0:  # 模式名稱欄位
                    cell.set_facecolor(colors[i])
                    cell.set_alpha(0.3)
                cell.set_text_props(weight='bold' if j == 0 else 'normal')
        
        # 設定標題行樣式
        for j in range(len(columns)):
            cell = table[(0, j)]
            cell.set_text_props(weight='bold')
            cell.set_facecolor('lightsteelblue')
        
        ax.axis('off')
        plt.tight_layout()
        
        stats_file = f'{output_dir}/detailed_statistics.png'
        plt.savefig(stats_file, bbox_inches='tight', dpi=300)
        plt.close()
        
        return stats_file
    
    def analyze_files(self, file_paths, output_dir='./analysis_results'):
        """
        主要分析函數
        
        Args:
            file_paths: CSV檔案路徑列表
            output_dir: 輸出目錄
            
        Returns:
            tuple: (資料字典, 生成的檔案列表)
        """
        
        print("=== 無線滑鼠耗電分析工具 ===")
        print(f"使用字體: {plt.rcParams['font.family']}")
        
        # 建立輸出目錄
        Path(output_dir).mkdir(exist_ok=True)
        
        # 載入資料
        data_dict = {}
        for filepath in file_paths:
            print(f"載入檔案：{filepath}")
            df = self.load_csv_file(filepath)
            if df is not None:
                mode = df['Mode'].iloc[0]
                data_dict[mode] = df
                print(f"  成功載入 {df['Mode_CN'].iloc[0]} 模式，{len(df)} 筆資料")
        
        if not data_dict:
            print("錯誤：沒有成功載入任何檔案")
            return None, []
        
        generated_files = []
        
        # 單檔分析
        if len(data_dict) == 1:
            print("\n執行單檔分析...")
            mode, df = next(iter(data_dict.items()))
            file = self.create_single_analysis(df, output_dir)
            generated_files.append(file)
            
        # 多檔比較分析
        if len(data_dict) > 1:
            print("\n執行多檔比較分析...")
            files = self.create_comparison_analysis(data_dict, output_dir)
            generated_files.extend(files)
            
            # 同時為每個模式建立單獨的詳細分析
            print("建立各模式詳細分析...")
            for mode, df in data_dict.items():
                file = self.create_single_analysis(df, output_dir)
                generated_files.append(file)
        
        # 輸出統計摘要
        print("\n=== 分析結果摘要 ===")
        for mode, df in data_dict.items():
            stats = self.calculate_statistics(df)
            battery_life = self.estimate_battery_life(stats['avg_power_W'])
            
            print(f"{stats['mode_cn']}：")
            print(f"  平均功率：{stats['avg_power_mW']:.2f} mW")
            print(f"  測量時間：{stats['duration_s']:.1f} 秒")
            print(f"  資料點數：{stats['data_points']} 筆")
            print(f"  預估續航：{battery_life['hours']:.1f} 小時")
        
        print(f"\n圖表已儲存至：{output_dir}")
        print(f"生成的檔案：{generated_files}")
        
        return data_dict, generated_files

def main():
    """命令列介面"""
    parser = argparse.ArgumentParser(description='無線滑鼠耗電分析工具')
    parser.add_argument('mode', choices=['single', 'multi'], 
                       help='分析模式：single=單檔分析, multi=多檔比較')
    parser.add_argument('files', nargs='+', help='CSV檔案路徑')
    parser.add_argument('-o', '--output', default='./analysis_results', 
                       help='輸出目錄 (預設: ./analysis_results)')
    
    args = parser.parse_args()
    
    # 檢查檔案是否存在
    for filepath in args.files:
        if not Path(filepath).exists():
            print(f"錯誤：檔案不存在 - {filepath}")
            sys.exit(1)
    
    # 執行分析
    analyzer = MousePowerAnalyzer()
    
    if args.mode == 'single' and len(args.files) > 1:
        print("警告：單檔模式只會分析第一個檔案")
        args.files = args.files[:1]
    
    data_dict, generated_files = analyzer.analyze_files(args.files, args.output)
    
    if data_dict:
        print(f"\n分析完成！共生成 {len(generated_files)} 個圖表檔案。")
    else:
        print("分析失敗！")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        main()
    else:
        # 預設執行範例分析
        file_paths = [
            '/home/ubuntu/upload/MD103Nolight2025-10-020.csv',
            '/home/ubuntu/upload/MD103Breath2025-10-020.csv',
            '/home/ubuntu/upload/MD103Colorcycle2025-10-020.csv',
            '/home/ubuntu/upload/MD103Flash2025-10-020.csv'
        ]
        
        analyzer = MousePowerAnalyzer()
        data_dict, generated_files = analyzer.analyze_files(file_paths, './mouse_analysis_results')
