#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
無線滑鼠耗電分析與視覺化工具
支援單檔分析和多檔比較
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# 設定中文字體和樣式
plt.rcParams['font.family'] = ['Noto Sans CJK TC', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.size'] = 10

# 設定顏色主題
COLORS = {
    'Nolight': '#2E8B57',      # 海綠色
    'Breath': '#4169E1',       # 皇家藍
    'Colorcycle': '#FF6347',   # 番茄紅
    'Flash': '#FFD700'         # 金色
}

MODE_NAMES = {
    'Nolight': '無燈光',
    'Breath': '呼吸燈',
    'Colorcycle': '彩色循環',
    'Flash': '閃爍'
}

def load_single_file(filepath, mode_name=None):
    """載入單一CSV檔案"""
    try:
        df = pd.read_csv(filepath)
        df.columns = ['Time', 'Voltage', 'Current', 'Power']
        
        # 如果沒有指定模式名稱，從檔名推測
        if mode_name is None:
            filename = Path(filepath).stem
            for mode, cn_name in MODE_NAMES.items():
                if mode.lower() in filename.lower():
                    mode_name = mode
                    break
            else:
                mode_name = 'Unknown'
        
        df['Mode'] = mode_name
        df['Mode_CN'] = MODE_NAMES.get(mode_name, mode_name)
        
        # 資料清理
        df = df.dropna()
        df = df[df['Power'] >= 0]
        
        return df
    except Exception as e:
        print(f"載入檔案 {filepath} 時發生錯誤：{e}")
        return None

def create_single_file_analysis(df, output_dir='./'):
    """為單一檔案建立完整分析圖表"""
    
    mode = df['Mode'].iloc[0]
    mode_cn = df['Mode_CN'].iloc[0]
    color = COLORS.get(mode, '#1f77b4')
    
    # 建立輸出目錄
    Path(output_dir).mkdir(exist_ok=True)
    
    # 1. 時間序列圖
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    fig.suptitle(f'{mode_cn} 模式 - 詳細分析', fontsize=16, fontweight='bold')
    
    # 功率時間序列
    axes[0,0].plot(df['Time'], df['Power']*1000, color=color, linewidth=1, alpha=0.8)
    axes[0,0].set_title('功率變化時間序列')
    axes[0,0].set_xlabel('時間 (秒)')
    axes[0,0].set_ylabel('功率 (mW)')
    axes[0,0].grid(True, alpha=0.3)
    
    # 電流時間序列
    axes[0,1].plot(df['Time'], df['Current']*1000, color=color, linewidth=1, alpha=0.8)
    axes[0,1].set_title('電流變化時間序列')
    axes[0,1].set_xlabel('時間 (秒)')
    axes[0,1].set_ylabel('電流 (mA)')
    axes[0,1].grid(True, alpha=0.3)
    
    # 功率分布直方圖
    axes[1,0].hist(df['Power']*1000, bins=50, color=color, alpha=0.7, edgecolor='black')
    axes[1,0].set_title('功率分布直方圖')
    axes[1,0].set_xlabel('功率 (mW)')
    axes[1,0].set_ylabel('頻次')
    axes[1,0].grid(True, alpha=0.3)
    
    # 統計摘要文字
    stats_text = f"""統計摘要：
平均功率：{df['Power'].mean()*1000:.2f} mW
最大功率：{df['Power'].max()*1000:.2f} mW
最小功率：{df['Power'].min()*1000:.2f} mW
標準差：{df['Power'].std()*1000:.2f} mW
平均電流：{df['Current'].mean()*1000:.2f} mA
測量時間：{df['Time'].max()-df['Time'].min():.1f} 秒
資料點數：{len(df)} 筆"""
    
    axes[1,1].text(0.1, 0.9, stats_text, transform=axes[1,1].transAxes, 
                   fontsize=10, verticalalignment='top', 
                   bbox=dict(boxstyle='round', facecolor='lightgray', alpha=0.8))
    axes[1,1].set_xlim(0, 1)
    axes[1,1].set_ylim(0, 1)
    axes[1,1].axis('off')
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/{mode}_detailed_analysis.png', bbox_inches='tight')
    plt.close()
    
    # 2. 功率分析圖
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    fig.suptitle(f'{mode_cn} 模式 - 功率分析', fontsize=16, fontweight='bold')
    
    # 移動平均
    window_size = max(10, len(df)//50)
    df_smooth = df.copy()
    df_smooth['Power_MA'] = df_smooth['Power'].rolling(window=window_size, center=True).mean()
    
    axes[0].plot(df['Time'], df['Power']*1000, color=color, alpha=0.3, label='原始資料')
    axes[0].plot(df_smooth['Time'], df_smooth['Power_MA']*1000, color='red', linewidth=2, label=f'移動平均({window_size}點)')
    axes[0].set_title('功率趨勢分析')
    axes[0].set_xlabel('時間 (秒)')
    axes[0].set_ylabel('功率 (mW)')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    
    # 功率變化率
    power_diff = np.diff(df['Power'])
    time_diff = np.diff(df['Time'])
    power_rate = power_diff / time_diff
    
    axes[1].plot(df['Time'][1:], power_rate*1000, color=color, alpha=0.7)
    axes[1].set_title('功率變化率')
    axes[1].set_xlabel('時間 (秒)')
    axes[1].set_ylabel('功率變化率 (mW/s)')
    axes[1].grid(True, alpha=0.3)
    
    # 累積能量消耗
    cumulative_energy = np.cumsum(df['Power'] * np.diff(np.concatenate([[0], df['Time']])))
    axes[2].plot(df['Time'], cumulative_energy, color=color, linewidth=2)
    axes[2].set_title('累積能量消耗')
    axes[2].set_xlabel('時間 (秒)')
    axes[2].set_ylabel('累積能量 (J)')
    axes[2].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/{mode}_power_analysis.png', bbox_inches='tight')
    plt.close()
    
    return f'{mode}_detailed_analysis.png', f'{mode}_power_analysis.png'

def create_multi_file_comparison(data_dict, output_dir='./'):
    """建立多檔案比較圖表"""
    
    # 建立輸出目錄
    Path(output_dir).mkdir(exist_ok=True)
    
    # 1. 功率比較圖
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    fig.suptitle('無線滑鼠不同發光模式耗電比較分析', fontsize=18, fontweight='bold')
    
    # 平均功率比較柱狀圖
    modes = list(data_dict.keys())
    avg_powers = [data_dict[mode]['Power'].mean()*1000 for mode in modes]
    mode_names_cn = [data_dict[mode]['Mode_CN'].iloc[0] for mode in modes]
    colors = [COLORS.get(mode, '#1f77b4') for mode in modes]
    
    bars = axes[0,0].bar(mode_names_cn, avg_powers, color=colors, alpha=0.8, edgecolor='black')
    axes[0,0].set_title('平均功率比較', fontweight='bold')
    axes[0,0].set_ylabel('平均功率 (mW)')
    axes[0,0].grid(True, alpha=0.3, axis='y')
    
    # 在柱狀圖上添加數值標籤
    for bar, power in zip(bars, avg_powers):
        axes[0,0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
                      f'{power:.1f}', ha='center', va='bottom', fontweight='bold')
    
    # 功率分布箱型圖
    power_data = [data_dict[mode]['Power']*1000 for mode in modes]
    bp = axes[0,1].boxplot(power_data, labels=mode_names_cn, patch_artist=True)
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
    axes[0,1].set_title('功率分布比較', fontweight='bold')
    axes[0,1].set_ylabel('功率 (mW)')
    axes[0,1].grid(True, alpha=0.3, axis='y')
    
    # 時間序列疊加圖
    for mode in modes:
        df = data_dict[mode]
        # 正規化時間到0-100%
        time_norm = (df['Time'] - df['Time'].min()) / (df['Time'].max() - df['Time'].min()) * 100
        axes[1,0].plot(time_norm, df['Power']*1000, 
                      color=COLORS.get(mode, '#1f77b4'), 
                      label=df['Mode_CN'].iloc[0], alpha=0.8, linewidth=1.5)
    
    axes[1,0].set_title('功率時間序列比較', fontweight='bold')
    axes[1,0].set_xlabel('時間進度 (%)')
    axes[1,0].set_ylabel('功率 (mW)')
    axes[1,0].legend()
    axes[1,0].grid(True, alpha=0.3)
    
    # 電池續航估算比較
    battery_capacity_mAh = 1000
    voltage = 3.7
    battery_energy_J = battery_capacity_mAh * voltage * 3.6
    
    battery_hours = []
    for mode in modes:
        avg_power_W = data_dict[mode]['Power'].mean()
        hours = battery_energy_J / (avg_power_W * 3600) if avg_power_W > 0 else 0
        battery_hours.append(hours)
    
    bars = axes[1,1].bar(mode_names_cn, battery_hours, color=colors, alpha=0.8, edgecolor='black')
    axes[1,1].set_title(f'預估電池續航 ({battery_capacity_mAh}mAh)', fontweight='bold')
    axes[1,1].set_ylabel('續航時間 (小時)')
    axes[1,1].grid(True, alpha=0.3, axis='y')
    
    # 在柱狀圖上添加數值標籤
    for bar, hours in zip(bars, battery_hours):
        axes[1,1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
                      f'{hours:.1f}h\n({hours/24:.1f}天)', ha='center', va='bottom', fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/multi_mode_comparison.png', bbox_inches='tight')
    plt.close()
    
    # 2. 詳細統計比較表
    fig, ax = plt.subplots(figsize=(14, 8))
    fig.suptitle('詳細統計比較表', fontsize=16, fontweight='bold')
    
    # 建立統計表格
    stats_data = []
    for mode in modes:
        df = data_dict[mode]
        duration = df['Time'].max() - df['Time'].min()
        total_energy = np.trapz(df['Power'], df['Time'])
        
        stats_data.append([
            df['Mode_CN'].iloc[0],
            f"{df['Power'].mean()*1000:.2f}",
            f"{df['Power'].max()*1000:.2f}",
            f"{df['Power'].std()*1000:.2f}",
            f"{df['Current'].mean()*1000:.2f}",
            f"{duration:.1f}",
            f"{total_energy:.3f}",
            f"{battery_energy_J/(df['Power'].mean()*3600):.1f}" if df['Power'].mean() > 0 else "∞"
        ])
    
    columns = ['模式', '平均功率\n(mW)', '最大功率\n(mW)', '功率標準差\n(mW)', 
               '平均電流\n(mA)', '測量時間\n(秒)', '總能量\n(J)', '預估續航\n(小時)']
    
    table = ax.table(cellText=stats_data, colLabels=columns, 
                    cellLoc='center', loc='center',
                    colColours=['lightblue']*len(columns))
    
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1.2, 2)
    
    # 設定表格樣式
    for i in range(len(modes)):
        for j in range(len(columns)):
            cell = table[(i+1, j)]
            if j == 0:  # 模式名稱欄位
                cell.set_facecolor(colors[i])
                cell.set_alpha(0.3)
    
    ax.axis('off')
    plt.tight_layout()
    plt.savefig(f'{output_dir}/statistics_table.png', bbox_inches='tight')
    plt.close()
    
    # 3. 能效分析圖
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    fig.suptitle('能效分析', fontsize=16, fontweight='bold')
    
    # 功率效率雷達圖（相對於無燈光模式）
    baseline_power = data_dict['Nolight']['Power'].mean() if 'Nolight' in data_dict else min(avg_powers)/1000
    
    efficiency_scores = []
    stability_scores = []
    
    for mode in modes:
        df = data_dict[mode]
        avg_power = df['Power'].mean()
        
        # 效率分數（基準功率/當前功率，越高越好）
        efficiency = baseline_power / avg_power if avg_power > 0 else 0
        efficiency_scores.append(efficiency)
        
        # 穩定性分數（1/變異係數，越高越穩定）
        cv = df['Power'].std() / df['Power'].mean() if df['Power'].mean() > 0 else float('inf')
        stability = 1 / cv if cv > 0 and cv != float('inf') else 0
        stability_scores.append(min(stability, 5))  # 限制最大值
    
    # 效率比較
    bars = axes[0].bar(mode_names_cn, efficiency_scores, color=colors, alpha=0.8, edgecolor='black')
    axes[0].set_title('功率效率分數\n(相對於基準模式)', fontweight='bold')
    axes[0].set_ylabel('效率分數')
    axes[0].grid(True, alpha=0.3, axis='y')
    
    for bar, score in zip(bars, efficiency_scores):
        axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                    f'{score:.2f}', ha='center', va='bottom', fontweight='bold')
    
    # 穩定性比較
    bars = axes[1].bar(mode_names_cn, stability_scores, color=colors, alpha=0.8, edgecolor='black')
    axes[1].set_title('功率穩定性分數\n(越高越穩定)', fontweight='bold')
    axes[1].set_ylabel('穩定性分數')
    axes[1].grid(True, alpha=0.3, axis='y')
    
    for bar, score in zip(bars, stability_scores):
        axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.05,
                    f'{score:.2f}', ha='center', va='bottom', fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/efficiency_analysis.png', bbox_inches='tight')
    plt.close()
    
    return ['multi_mode_comparison.png', 'statistics_table.png', 'efficiency_analysis.png']

def analyze_files(file_paths, output_dir='./analysis_results'):
    """主要分析函數 - 支援單檔或多檔分析"""
    
    print("=== 無線滑鼠耗電分析工具 ===")
    
    # 建立輸出目錄
    Path(output_dir).mkdir(exist_ok=True)
    
    # 載入資料
    data_dict = {}
    for filepath in file_paths:
        print(f"載入檔案：{filepath}")
        df = load_single_file(filepath)
        if df is not None:
            mode = df['Mode'].iloc[0]
            data_dict[mode] = df
            print(f"  成功載入 {df['Mode_CN'].iloc[0]} 模式，{len(df)} 筆資料")
    
    if not data_dict:
        print("錯誤：沒有成功載入任何檔案")
        return
    
    generated_files = []
    
    # 單檔分析
    if len(data_dict) == 1:
        print("\n執行單檔分析...")
        mode, df = next(iter(data_dict.items()))
        files = create_single_file_analysis(df, output_dir)
        generated_files.extend(files)
        
    # 多檔比較分析
    if len(data_dict) > 1:
        print("\n執行多檔比較分析...")
        files = create_multi_file_comparison(data_dict, output_dir)
        generated_files.extend(files)
    
    # 輸出統計摘要
    print("\n=== 分析結果摘要 ===")
    for mode, df in data_dict.items():
        mode_cn = df['Mode_CN'].iloc[0]
        avg_power_mw = df['Power'].mean() * 1000
        duration = df['Time'].max() - df['Time'].min()
        
        print(f"{mode_cn}：")
        print(f"  平均功率：{avg_power_mw:.2f} mW")
        print(f"  測量時間：{duration:.1f} 秒")
        print(f"  資料點數：{len(df)} 筆")
    
    print(f"\n圖表已儲存至：{output_dir}")
    print(f"生成的檔案：{generated_files}")
    
    return data_dict, generated_files

if __name__ == "__main__":
    # 範例使用：分析當前的四個檔案
    file_paths = [
        '/home/ubuntu/upload/MD103Nolight2025-10-020.csv',
        '/home/ubuntu/upload/MD103Breath2025-10-020.csv',
        '/home/ubuntu/upload/MD103Colorcycle2025-10-020.csv',
        '/home/ubuntu/upload/MD103Flash2025-10-020.csv'
    ]
    
    # 執行分析
    data_dict, generated_files = analyze_files(file_paths, './mouse_analysis_results')
