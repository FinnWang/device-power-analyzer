#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
進階耗電分析 - 計算詳細統計和比較分析
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# 設定中文字體
plt.rcParams['font.family'] = ['Noto Sans CJK TC', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

def load_all_data():
    """載入所有資料並合併"""
    
    files = {
        'Nolight': '/home/ubuntu/upload/MD103Nolight2025-10-020.csv',
        'Breath': '/home/ubuntu/upload/MD103Breath2025-10-020.csv', 
        'Colorcycle': '/home/ubuntu/upload/MD103Colorcycle2025-10-020.csv',
        'Flash': '/home/ubuntu/upload/MD103Flash2025-10-020.csv'
    }
    
    mode_names = {
        'Nolight': '無燈光',
        'Breath': '呼吸燈',
        'Colorcycle': '彩色循環',
        'Flash': '閃爍'
    }
    
    all_data = []
    
    for mode, filepath in files.items():
        df = pd.read_csv(filepath)
        df.columns = ['Time', 'Voltage', 'Current', 'Power']
        df['Mode'] = mode
        df['Mode_CN'] = mode_names[mode]
        df = df.dropna()
        df = df[df['Power'] >= 0]
        all_data.append(df)
    
    return pd.concat(all_data, ignore_index=True)

def calculate_detailed_statistics(df):
    """計算詳細統計數據"""
    
    stats_by_mode = df.groupby(['Mode', 'Mode_CN']).agg({
        'Time': ['min', 'max', 'count'],
        'Voltage': ['mean', 'std', 'min', 'max'],
        'Current': ['mean', 'std', 'min', 'max'],
        'Power': ['mean', 'std', 'min', 'max', 'median']
    }).round(6)
    
    # 計算每個模式的總能量消耗
    energy_consumption = {}
    for mode in df['Mode'].unique():
        mode_data = df[df['Mode'] == mode].copy()
        mode_data = mode_data.sort_values('Time')
        
        # 使用梯形積分計算總能量
        total_energy = np.trapz(mode_data['Power'], mode_data['Time'])
        duration = mode_data['Time'].max() - mode_data['Time'].min()
        
        energy_consumption[mode] = {
            'total_energy_J': total_energy,
            'duration_s': duration,
            'avg_power_W': mode_data['Power'].mean(),
            'energy_per_hour_J': total_energy / duration * 3600 if duration > 0 else 0,
            'mode_cn': mode_data['Mode_CN'].iloc[0]
        }
    
    return stats_by_mode, energy_consumption

def calculate_power_efficiency_metrics(df):
    """計算功率效率指標"""
    
    efficiency_metrics = {}
    
    # 以無燈光模式作為基準
    baseline_power = df[df['Mode'] == 'Nolight']['Power'].mean()
    
    for mode in df['Mode'].unique():
        mode_data = df[df['Mode'] == mode]
        avg_power = mode_data['Power'].mean()
        
        efficiency_metrics[mode] = {
            'mode_cn': mode_data['Mode_CN'].iloc[0],
            'avg_power_mW': avg_power * 1000,
            'power_increase_vs_baseline': ((avg_power - baseline_power) / baseline_power * 100) if baseline_power > 0 else 0,
            'power_efficiency_score': baseline_power / avg_power if avg_power > 0 else 0,
            'current_draw_mA': mode_data['Current'].mean() * 1000,
            'power_stability': 1 / (mode_data['Power'].std() / mode_data['Power'].mean()) if mode_data['Power'].std() > 0 else float('inf')
        }
    
    return efficiency_metrics

def analyze_power_patterns(df):
    """分析功率變化模式"""
    
    pattern_analysis = {}
    
    for mode in df['Mode'].unique():
        mode_data = df[df['Mode'] == mode].copy()
        mode_data = mode_data.sort_values('Time')
        
        # 計算功率變化率
        power_diff = np.diff(mode_data['Power'])
        time_diff = np.diff(mode_data['Time'])
        power_rate = power_diff / time_diff
        
        # 檢測峰值和谷值
        from scipy.signal import find_peaks
        peaks, _ = find_peaks(mode_data['Power'], height=mode_data['Power'].mean())
        valleys, _ = find_peaks(-mode_data['Power'], height=-mode_data['Power'].mean())
        
        pattern_analysis[mode] = {
            'mode_cn': mode_data['Mode_CN'].iloc[0],
            'avg_power_change_rate': np.mean(np.abs(power_rate)),
            'max_power_change_rate': np.max(np.abs(power_rate)),
            'num_peaks': len(peaks),
            'num_valleys': len(valleys),
            'power_range': mode_data['Power'].max() - mode_data['Power'].min(),
            'coefficient_of_variation': mode_data['Power'].std() / mode_data['Power'].mean()
        }
    
    return pattern_analysis

def estimate_battery_life(energy_consumption, battery_capacity_mAh=1000, voltage=3.7):
    """估算電池續航時間"""
    
    battery_energy_J = battery_capacity_mAh * voltage * 3.6  # 轉換為焦耳
    
    battery_estimates = {}
    
    for mode, data in energy_consumption.items():
        avg_power_W = data['avg_power_W']
        
        if avg_power_W > 0:
            estimated_hours = battery_energy_J / (avg_power_W * 3600)
            estimated_days = estimated_hours / 24
            
            battery_estimates[mode] = {
                'mode_cn': data['mode_cn'],
                'estimated_hours': estimated_hours,
                'estimated_days': estimated_days,
                'avg_power_mW': avg_power_W * 1000
            }
    
    return battery_estimates

if __name__ == "__main__":
    print("=== 進階耗電分析 ===")
    
    # 載入所有資料
    print("載入資料...")
    df = load_all_data()
    
    # 詳細統計分析
    print("計算詳細統計...")
    stats, energy_consumption = calculate_detailed_statistics(df)
    
    # 功率效率分析
    print("分析功率效率...")
    efficiency_metrics = calculate_power_efficiency_metrics(df)
    
    # 功率模式分析
    print("分析功率變化模式...")
    try:
        # 安裝 scipy 如果需要
        import subprocess
        subprocess.run(['pip3', 'install', 'scipy'], capture_output=True)
        pattern_analysis = analyze_power_patterns(df)
    except:
        print("無法進行功率模式分析（需要 scipy）")
        pattern_analysis = {}
    
    # 電池續航估算
    print("估算電池續航...")
    battery_estimates = estimate_battery_life(energy_consumption)
    
    # 輸出分析結果
    print("\n=== 功率效率比較 ===")
    for mode, metrics in efficiency_metrics.items():
        print(f"\n{metrics['mode_cn']}：")
        print(f"  平均功率：{metrics['avg_power_mW']:.2f} mW")
        print(f"  相對基準增加：{metrics['power_increase_vs_baseline']:.1f}%")
        print(f"  平均電流：{metrics['current_draw_mA']:.2f} mA")
        print(f"  功率穩定性：{metrics['power_stability']:.2f}")
    
    print("\n=== 電池續航估算 (1000mAh, 3.7V) ===")
    for mode, estimate in battery_estimates.items():
        print(f"{estimate['mode_cn']}：{estimate['estimated_hours']:.1f} 小時 ({estimate['estimated_days']:.1f} 天)")
    
    print("\n進階分析完成！")
