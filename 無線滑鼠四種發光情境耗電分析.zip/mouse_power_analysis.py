#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
無線滑鼠不同發光情境耗電分析
分析四種發光模式：無燈光、呼吸燈、彩色循環、閃爍
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# 設定中文字體
plt.rcParams['font.family'] = ['Noto Sans CJK TC', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

def load_and_process_data():
    """載入並處理四個CSV檔案"""
    
    # 檔案路徑和對應的模式名稱
    files = {
        'Nolight': '/home/ubuntu/upload/MD103Nolight2025-10-020.csv',
        'Breath': '/home/ubuntu/upload/MD103Breath2025-10-020.csv', 
        'Colorcycle': '/home/ubuntu/upload/MD103Colorcycle2025-10-020.csv',
        'Flash': '/home/ubuntu/upload/MD103Flash2025-10-020.csv'
    }
    
    # 中文模式名稱對應
    mode_names = {
        'Nolight': '無燈光',
        'Breath': '呼吸燈',
        'Colorcycle': '彩色循環',
        'Flash': '閃爍'
    }
    
    data_dict = {}
    
    for mode, filepath in files.items():
        try:
            # 讀取CSV檔案
            df = pd.read_csv(filepath)
            
            # 重新命名欄位為更簡潔的名稱
            df.columns = ['Time', 'Voltage', 'Current', 'Power']
            
            # 添加模式標籤
            df['Mode'] = mode
            df['Mode_CN'] = mode_names[mode]
            
            # 基本資料清理
            df = df.dropna()  # 移除空值
            df = df[df['Power'] >= 0]  # 移除負功率值（如果有的話）
            
            data_dict[mode] = df
            
            print(f"已載入 {mode_names[mode]} 模式資料：{len(df)} 筆記錄")
            print(f"  時間範圍：{df['Time'].min():.2f} - {df['Time'].max():.2f} 秒")
            print(f"  平均功率：{df['Power'].mean():.6f} W")
            print(f"  最大功率：{df['Power'].max():.6f} W")
            print()
            
        except Exception as e:
            print(f"載入 {mode} 檔案時發生錯誤：{e}")
    
    return data_dict

def calculate_statistics(data_dict):
    """計算各模式的統計數據"""
    
    stats = {}
    
    for mode, df in data_dict.items():
        mode_cn = df['Mode_CN'].iloc[0]
        
        stats[mode] = {
            'mode_cn': mode_cn,
            'duration': df['Time'].max() - df['Time'].min(),
            'avg_voltage': df['Voltage'].mean(),
            'avg_current': df['Current'].mean(),
            'avg_power': df['Power'].mean(),
            'max_power': df['Power'].max(),
            'min_power': df['Power'].min(),
            'std_power': df['Power'].std(),
            'total_energy': np.trapz(df['Power'], df['Time']),  # 使用梯形積分計算總能量
            'data_points': len(df)
        }
    
    return stats

if __name__ == "__main__":
    print("=== 無線滑鼠耗電分析 ===")
    print("載入資料中...")
    
    # 載入資料
    data_dict = load_and_process_data()
    
    # 計算統計數據
    print("計算統計數據...")
    stats = calculate_statistics(data_dict)
    
    # 顯示統計摘要
    print("\n=== 統計摘要 ===")
    for mode, stat in stats.items():
        print(f"\n{stat['mode_cn']} 模式：")
        print(f"  測量時間：{stat['duration']:.1f} 秒")
        print(f"  平均電壓：{stat['avg_voltage']:.3f} V")
        print(f"  平均電流：{stat['avg_current']:.6f} A")
        print(f"  平均功率：{stat['avg_power']:.6f} W ({stat['avg_power']*1000:.3f} mW)")
        print(f"  最大功率：{stat['max_power']:.6f} W ({stat['max_power']*1000:.3f} mW)")
        print(f"  功率標準差：{stat['std_power']:.6f} W")
        print(f"  總消耗能量：{stat['total_energy']:.6f} J")
    
    print("\n資料預處理完成！")
